﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using CapstoneApi.User;

namespace CapstoneApi.Admin
{
    public class CouponImplementation : IAdminRepository
    {
        string Cs = ConfigurationManager.ConnectionStrings["DataBase"].ConnectionString;
        public string ActivateCoupon(string coupon)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spActivateCouponbyCouponCode", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CouponCode", coupon);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Activated Successfully";    
            }
        }

        public string DeactvateCoupons(string coupon)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spDeactivateCouponbyCouponCode", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CouponCode", coupon);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Deactivated  Successfully";
            }
        }

        public List<AddCoupon> GetCoupon()
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<AddCoupon> coupons = new List<AddCoupon>();
                SqlCommand cmd = new SqlCommand("spShowCoupons", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    AddCoupon coupon = new AddCoupon();
                    coupon.CouponId = reader.GetInt32(0);
                    coupon.CouponCode = reader.GetString(1);
                    coupon.CouponDiscount = reader.GetInt32(2);
                    coupon.Status = reader.GetBoolean(3);


                    coupons.Add(coupon);
                }
                return coupons;

            }
        }

        public List<AddCoupon> GetCouponById(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<AddCoupon> coupons = new List<AddCoupon>();
                SqlCommand cmd = new SqlCommand("spGetCouponbyId", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CouponId", id);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    AddCoupon coupon = new AddCoupon();
                    coupon.CouponCode = reader.GetString(1);
                    coupon.CouponDiscount = reader.GetInt32(2);
                    

                    coupons.Add(coupon);
                }
                return coupons;

            }
        }

        public List<RegisterUser> GetBlockedUser()
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<RegisterUser> users = new List<RegisterUser>();
                SqlCommand cmd = new SqlCommand("spGetBlockedApplicationUserList", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    RegisterUser user = new RegisterUser();
                    user.UserId = reader.GetInt32(0);
                    user.Username = reader.GetString(1);
                    //user.status = reader.GetBoolean(6);
                    //user.gender = reader.GetString(7);
                    user.Email = reader.GetString(4);
                    user.contact = reader.GetString(3);


                    users.Add(user);
                }
                return users;

            }

        
        }

        public string InsertCoupon(AddCoupon coupon)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spAddCoupon", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CouponCode", coupon.CouponCode);
                cmd.Parameters.AddWithValue("@CouponDiscount", coupon.CouponDiscount);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Inserted Successfully";
            }
        }

        public string ActivateUser(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spActivateUser", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserId", id);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Feature";
            }
        }

        public string BlockUser(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spDeactivateUser", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserId", id);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Feature";
            }
        }

        public List<AddCoupon> GetActivatedCoupons()
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<AddCoupon> coupons = new List<AddCoupon>();
                SqlCommand cmd = new SqlCommand("spActivatedCoupons", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    AddCoupon coupon = new AddCoupon();
                    coupon.CouponCode = reader.GetString(1);
                    coupon.CouponDiscount = reader.GetInt32(2);


                    coupons.Add(coupon);
                }
                return coupons;

            }
        }
    }
}