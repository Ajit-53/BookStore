﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CapstoneApi.Admin
{
    public class DeactvateCoupon
    {
        public bool Status { get; set; }
        public string CouponCode { get; set; }
    }
}