﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapstoneApi.User;

namespace CapstoneApi.Admin
{
    interface IAdminRepository
    {
        string InsertCoupon(AddCoupon coupon);
        string ActivateCoupon(string coupon);
        string DeactvateCoupons(string coupon);
        List<AddCoupon> GetCouponById(int id);
        List<AddCoupon> GetCoupon();
        List<AddCoupon> GetActivatedCoupons();
        string ActivateUser(int id);
        string BlockUser(int id);
        List<RegisterUser> GetBlockedUser();

    }
}
