﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CapstoneApi.Admin
{
    public class AddCoupon
    {
        public int CouponId { get; set; }
        public string CouponCode { get; set; }
        public int CouponDiscount { get; set; }
        public bool Status { get; set; }
    }
}