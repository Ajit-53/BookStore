﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CapstoneApi.User
{
    public class RegisterUser
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string contact { get; set; }
        public string Email { get; set; }
        public string password { get; set; }
        public string gender { get; set; }
        public bool status { get; set; }
        
    }

    
}