﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace CapstoneApi.User
{
    public class UserImplementation : IUserRepository
    {
        string Cs = ConfigurationManager.ConnectionStrings["DataBase"].ConnectionString;

        public string AddToCart(Cart cart)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                SqlCommand cmd = new SqlCommand("spAddToCartss", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserId", cart.UserId);
                cmd.Parameters.AddWithValue("@ItemName", cart.ItemName);
                cmd.Parameters.AddWithValue("@ItemPrice", cart.ItemPrice);
                cmd.Parameters.AddWithValue("@ItemId", cart.ItemId);
                cmd.Parameters.AddWithValue("@ItemDesc", cart.ItemDesc);
               // cmd.Parameters.AddWithValue("@ItemUrl", cart.ImgUrl);
                cmd.Parameters.AddWithValue("@ItemQuantity", cart.ItemQuant);
                con.Open();
                cmd.ExecuteNonQuery();
                return "Successfully Added";

            }
        }

        public string AddToWhislist(Cart cart)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                SqlCommand cmd = new SqlCommand("spAddsToWhislistss", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserId", cart.UserId);
                cmd.Parameters.AddWithValue("@ItemName", cart.ItemName);
                cmd.Parameters.AddWithValue("@ItemPrice", cart.ItemPrice);
                cmd.Parameters.AddWithValue("@ItemId", cart.ItemId);
                cmd.Parameters.AddWithValue("@ItemDesc", cart.ItemDesc);
                con.Open();
                cmd.ExecuteNonQuery();
                return "Successfully Added";

            }
        }

        public string AddUser(RegisterUser user)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                SqlCommand cmd = new SqlCommand("spAddApplicationUsers", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserName",user.Username );
                cmd.Parameters.AddWithValue("@UserGender",user.gender );
                cmd.Parameters.AddWithValue("@UserContact",user.contact);
                cmd.Parameters.AddWithValue("@UserEmail", user.Email);
                cmd.Parameters.AddWithValue("@UserPassword",user.password);
                SqlParameter output = new SqlParameter();
                output.ParameterName = "@UserId";
                output.SqlDbType = SqlDbType.Int;
                output.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(output);
                con.Open();
                cmd.ExecuteNonQuery();
                return output.Value.ToString();

            }
        }

        public string CartItemCount(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                
                SqlCommand cmd = new SqlCommand("spCountCartItems", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserId", id);
                con.Open();
                 var getvalue= cmd.ExecuteScalar();

                return getvalue.ToString();
            }

        }

        public string DeleteFromCart(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spDeleteCartBook", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@BookId", id);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Deleted Successfully";
            }
        }

        public string DeleteFromWhislist(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spDeleteWhislistBook", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@BookId", id);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Deleted Successfully";
            }
        }

        public List<Cart> GetCartItemByUserId(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<Cart> carts = new List<Cart>();
                SqlCommand cmd = new SqlCommand("spGetCartItemsByUserId", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserId", id);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Cart cart = new Cart();
                    cart.Id = reader.GetInt32(0);
                    cart.UserId = reader.GetInt32(1);
                    cart.ItemName = reader.GetString(2);
                    cart.ItemPrice = reader.GetInt32(3);
                    cart.ItemQuant = reader.GetInt32(7);
                    cart.ItemDesc = reader.GetString(5);
                    cart.ItemId = reader.GetInt32(4);
                    //cart.ImgUrl = reader.GetString(8);
                    carts.Add(cart);


                }
                return carts;

            }
        }

        public List<Cart> GetWhislistItemsByUserId(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<Cart> carts = new List<Cart>();
                SqlCommand cmd = new SqlCommand("spGetWhislistItemsByUserId", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserId", id);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Cart cart = new Cart();
                    cart.Id = reader.GetInt32(0);
                    cart.UserId = reader.GetInt32(1);
                    cart.ItemName = reader.GetString(2);
                    cart.ItemPrice = reader.GetInt32(3);
                   // cart.ItemQuant = reader.GetInt32(7);
                    cart.ItemDesc = reader.GetString(5);
                    cart.ItemId = reader.GetInt32(4);
                    //cart.ImgUrl = reader.GetString(8);
                    carts.Add(cart);


                }
                return carts;

            }
        }

        public LoginAdmin Loginadmin(LoginAdmin admin)
        {
           
            
                using (SqlConnection con = new SqlConnection(Cs))
                {
                    LoginAdmin la = new LoginAdmin();
                    SqlCommand cmd = new SqlCommand("spLoginAdmin", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserName", admin.username);
                    cmd.Parameters.AddWithValue("@pass", admin.password);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                   if(reader.Read()) { 
                    {
                        la.username = reader.GetString(1);


                    }
                
                

                    return la;
                }
                else
                {
                    return null;
                }
                }
            
           
            
            
        }

        public RegisterUser Loginuser(LoginUser user)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                RegisterUser users = new RegisterUser();
                SqlCommand cmd = new SqlCommand("spLoginUser", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserName", user.username);
                cmd.Parameters.AddWithValue("@pass", user.password);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    {
                        users.Username = reader.GetString(1);
                        users.UserId = reader.GetInt32(0);


                    }

                    return users;
                }
                else
                {
                    return null;
                }
            }
        }

        public string UpdateItemQuantInCart(int quant, int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spUpdateQuantityInCart", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@BookId", id);
                cmd.Parameters.AddWithValue("@Count", quant);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Updated";
            }
        }

        public string WhislistItemCount(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spCountWhislistItems", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserId", id);
                con.Open();
                var getvalue = cmd.ExecuteScalar();

                return getvalue.ToString();
            }
        }
    }
}