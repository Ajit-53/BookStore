﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CapstoneApi.User
{
    public class LoginAdmin
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}