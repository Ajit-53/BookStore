﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CapstoneApi.User
{
    public class LoginUser
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}