﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapstoneApi.User
{
    interface IUserRepository
    {
        string AddUser(RegisterUser user);
        LoginAdmin Loginadmin(LoginAdmin admin);
        RegisterUser Loginuser(LoginUser user);

       List<Cart> GetCartItemByUserId(int id);
        List<Cart> GetWhislistItemsByUserId(int id);
        string DeleteFromCart(int id);
        string DeleteFromWhislist(int id);
        string UpdateItemQuantInCart(int quant, int id);
        string AddToCart(Cart cart);
        string AddToWhislist(Cart cart);
        string CartItemCount(int id);
        string WhislistItemCount(int id);
    }
}
