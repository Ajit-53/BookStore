﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CapstoneApi.Books
{
    public class BookCategory
    {
        public int Id { get; set; }
        public int CatId { get; set; }
        public string CatName { get; set; }
        
        public bool Status { get; set; }
    }
}