﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapstoneApi.Books
{
    interface IBookRepository
    {
        List<BookTitle> GetBookTitles();
        string InsertBookTitle(BookTitle book);
        string InsertBookCategory(BookCategory book);
        string InsertBookSubCategory(BookSubCategory book);
        List<BookCategory> GetBookCategories();
        List<BookSubCategory> GetBookSubCategories();
        List<BookSubCategory> GetBookSubCategoriesbyPage(int pageno);
        List<BookCategory> GetBookCategoriesbyCatId(int id);
        List<BookSubCategory> GetBookSubCategoriesbyCatId(int id);
        List<BookSubCategory> GetBookSubCategoriesbySubId(int id);
        BookSubCategory GetBookSubCategorybyId(int id);
        List<BookSubCategory> GetBookSubCategoriesAlphabatically();
        List<BookSubCategory> GetBookSubCategoriesbyPriceInc();
        List<BookSubCategory> GetBookSubCategoriesbyPriceDesc();
        List<BookSubCategory> GetBookSubCategorieswithZeroStatus();
        List<BookSubCategory> GetFeaturedBook();
        string MakeFeatureBook(int id);
        string MakeVisible(int id);
        string MakeHidden(int id);
        string MakeNonFeaturedBook(int id);
        string ActivateBook(int id);
        string DeactivateBook(int id);
        string DeleteBook(int id);
        string UpdateBook(int id,BookSubCategory book);


    }
}
