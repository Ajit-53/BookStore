﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace CapstoneApi.Books
{
   
    public class BookImplementation : IBookRepository
    {
        string Cs= ConfigurationManager.ConnectionStrings["DataBase"].ConnectionString;

        public string ActivateBook(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spActivateBookss", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@BookId",id);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Activated Successfully";
            }
        }

        public string DeactivateBook(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spDeactivateBooks", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@BookId", id);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Deactivated  Successfully";
            }
        }

        public string DeleteBook(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spDeleteBook", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@BookId", id);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Deleted Successfully";
            }
        }

        public List<BookCategory> GetBookCategories()
        {

            using(SqlConnection con=new SqlConnection(Cs))
            {
                List<BookCategory> books = new List<BookCategory>();
                SqlCommand cmd = new SqlCommand("spGetBookCategory", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    BookCategory book = new BookCategory();
                    book.Id = reader.GetInt32(0);
                    book.CatId = reader.GetInt32(1);
                    book.CatName = reader.GetString(2);
                   
                    books.Add(book);
                }
                return books;
            
            }
        }

        public List<BookCategory> GetBookCategoriesbyCatId(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<BookCategory> books = new List<BookCategory>();
                SqlCommand cmd = new SqlCommand("spGetBooksCategoryByCatId", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", id);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    BookCategory book = new BookCategory();
                    book.Id = reader.GetInt32(0);
                    book.CatId = reader.GetInt32(1);
                    book.CatName = reader.GetString(2);
                    book.Status = reader.GetBoolean(4);
                    books.Add(book);


                }
                return books;

            }

        }

        public List<BookSubCategory> GetBookSubCategories()
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<BookSubCategory> books = new List<BookSubCategory>();
                SqlCommand cmd = new SqlCommand("spShowSubCategoryWithStatus", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    BookSubCategory book = new BookSubCategory();
                    book.Id = reader.GetInt32(0);
                book.CatId = reader.GetInt32(1);
                book.SubId = reader.GetInt32(2);
                book.SubName = reader.GetString(3);
                book.SubDesc = reader.GetString(4);
                book.Price = reader.GetInt32(5);
                book.Photo = reader.GetString(6);
                book.Status = reader.GetBoolean(7);
                book.ISBN = reader.GetInt32(9);
                books.Add(book);

                   
                }
                return books;

            }
        }


        public List<BookSubCategory> GetBookSubCategoriesbyPage(int pageno)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Cs))
                {
                    List<BookSubCategory> books = new List<BookSubCategory>();
                    List<BookSubCategory> rangeofbooks = new List<BookSubCategory>();

                    SqlCommand cmd = new SqlCommand("spShowSubCategoryWithStatus", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        BookSubCategory book = new BookSubCategory();
                        book.Id = reader.GetInt32(0);
                        book.CatId = reader.GetInt32(1);
                        book.SubId = reader.GetInt32(2);
                        book.SubName = reader.GetString(3);
                        book.SubDesc = reader.GetString(4);
                        book.Price = reader.GetInt32(5);
                        book.Photo = reader.GetString(6);
                        book.Status = reader.GetBoolean(7);
                        book.ISBN = reader.GetInt32(9);
                        books.Add(book);


                    }
                    rangeofbooks = books.GetRange((pageno - 1) * 4, 4);
                    return rangeofbooks;


                }
            }catch(Exception e)
            {
                throw e;
            }
        }

        public List<BookSubCategory> GetBookSubCategoriesAlphabatically()
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<BookSubCategory> books = new List<BookSubCategory>();
                SqlCommand cmd = new SqlCommand("spGetBooksSubCategoryAlphabatically", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    BookSubCategory book = new BookSubCategory();
                    book.Id = reader.GetInt32(0);
                    book.CatId = reader.GetInt32(1);
                    book.SubId = reader.GetInt32(2);
                    book.SubName = reader.GetString(3);
                    book.SubDesc = reader.GetString(4);
                    book.Price = reader.GetInt32(5);
                    book.Photo = reader.GetString(6);
                    book.Status = reader.GetBoolean(7);
                    book.ISBN = reader.GetInt32(9);
                    books.Add(book);


                }
                
                return books;
            }



            }

            public List<BookSubCategory> GetBookSubCategoriesbyCatId(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<BookSubCategory> books = new List<BookSubCategory>();
                SqlCommand cmd = new SqlCommand("spGetBooksSubCategoryByCatId", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", id);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    BookSubCategory book = new BookSubCategory();
                    book.Id = reader.GetInt32(0);
                    book.CatId = reader.GetInt32(1);
                    book.SubId = reader.GetInt32(2);
                    book.SubName = reader.GetString(3);
                    book.SubDesc = reader.GetString(4);
                    book.Price = reader.GetInt32(5);
                    book.Photo = reader.GetString(6);
                    book.Status = reader.GetBoolean(7);
                    book.ISBN = reader.GetInt32(9);
                    books.Add(book);


                }
                return books;

            }
        }

        public List<BookSubCategory> GetBookSubCategoriesbyPriceDesc()
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<BookSubCategory> books = new List<BookSubCategory>();
                SqlCommand cmd = new SqlCommand("spGetBooksSubCategorybyPriceDecrease", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    BookSubCategory book = new BookSubCategory();
                    book.Id = reader.GetInt32(0);
                    book.CatId = reader.GetInt32(1);
                    book.SubId = reader.GetInt32(2);
                    book.SubName = reader.GetString(3);
                    book.SubDesc = reader.GetString(4);
                    book.Price = reader.GetInt32(5);
                    book.Photo = reader.GetString(6);
                    book.Status = reader.GetBoolean(7);
                    book.ISBN = reader.GetInt32(9);
                    books.Add(book);


                }
                
                return books;
            }
        }

        public List<BookSubCategory> GetBookSubCategoriesbyPriceInc()
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<BookSubCategory> books = new List<BookSubCategory>();
                SqlCommand cmd = new SqlCommand("spGetBooksSubCategorybyPriceIncrease", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    BookSubCategory book = new BookSubCategory();
                    book.Id = reader.GetInt32(0);
                    book.CatId = reader.GetInt32(1);
                    book.SubId = reader.GetInt32(2);
                    book.SubName = reader.GetString(3);
                    book.SubDesc = reader.GetString(4);
                    book.Price = reader.GetInt32(5);
                    book.Photo = reader.GetString(6);
                    book.Status = reader.GetBoolean(7);
                    book.ISBN = reader.GetInt32(9);
                    books.Add(book);


                }
                return books;
            }
        }

        public List<BookSubCategory> GetBookSubCategoriesbySubId(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<BookSubCategory> books = new List<BookSubCategory>();
                SqlCommand cmd = new SqlCommand("spGetBooksSubCategoryBySubId", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", id);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    BookSubCategory book = new BookSubCategory();
                    book.Id = reader.GetInt32(0);
                    book.CatId = reader.GetInt32(1);
                    book.SubId = reader.GetInt32(2);
                    book.SubName = reader.GetString(3);
                    book.SubDesc = reader.GetString(4);
                    book.Price = reader.GetInt32(5);
                    book.Photo = reader.GetString(6);
                    book.Status = reader.GetBoolean(7);
                    book.ISBN = reader.GetInt32(9);
                    books.Add(book);


                }
                return books;

            }
        }

        public List<BookSubCategory> GetBookSubCategorieswithZeroStatus()
        {

            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<BookSubCategory> books = new List<BookSubCategory>();
                SqlCommand cmd = new SqlCommand("spShowSubCategoryWithZeroStatus", con);
                cmd.CommandType = CommandType.StoredProcedure;  
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    BookSubCategory book = new BookSubCategory();
                    book.Id = reader.GetInt32(0);
                    book.CatId = reader.GetInt32(1);
                    book.SubId = reader.GetInt32(2);
                    book.SubName = reader.GetString(3);
                    book.SubDesc = reader.GetString(4);
                    book.Price = reader.GetInt32(5);
                    book.Photo = reader.GetString(6);
                    book.Status = reader.GetBoolean(7);
                    book.ISBN = reader.GetInt32(9);
                    books.Add(book);


                }
                return books;

            }
        }

        public BookSubCategory GetBookSubCategorybyId(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                BookSubCategory book = new BookSubCategory();
                SqlCommand cmd = new SqlCommand("spGetBooksSubCategoryById", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", id);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                reader.Read();
                {

                    book.Id = reader.GetInt32(0);
                    book.SubName = reader.GetString(3);
                    book.SubDesc = reader.GetString(4);
                    book.Price = reader.GetInt32(5);
                    book.Photo = reader.GetString(6);
                    book.ISBN = reader.GetInt32(9);
                   


                }
                return book;
            }
        }

        public List<BookTitle> GetBookTitles()
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<BookTitle> books = new List<BookTitle>();
                SqlCommand cmd = new SqlCommand("spGetBookTitle", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    BookTitle book = new BookTitle();
                    book.BookId = reader.GetInt32(0);
                    book.Title = reader.GetString(1);

                    books.Add(book);
                }
                return books;

            }
        }

        public List<BookSubCategory> GetFeaturedBook()
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<BookSubCategory> books = new List<BookSubCategory>();
                SqlCommand cmd = new SqlCommand("spShowFeaturedBooks", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    BookSubCategory book = new BookSubCategory();
                    book.Id = reader.GetInt32(0);
                    book.CatId = reader.GetInt32(1);
                    book.SubId = reader.GetInt32(2);
                    book.SubName = reader.GetString(3);
                    book.SubDesc = reader.GetString(4);
                    book.Price = reader.GetInt32(5);
                    book.Photo = reader.GetString(6);
                    book.Status = reader.GetBoolean(7);
                    book.ISBN = reader.GetInt32(9);
                    books.Add(book);


                }
                return books;
            }


            }

            public string InsertBookCategory(BookCategory book)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
               
                SqlCommand cmd = new SqlCommand("spAddBookCategory", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CatId", book.CatId);
                cmd.Parameters.AddWithValue("@CatName", book.CatName);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Inserted Successfully";
            }
        }

        public string InsertBookSubCategory(BookSubCategory book)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<BookTitle> books = new List<BookTitle>();
                SqlCommand cmd = new SqlCommand("spAddBooksSubCategory", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CatId", book.CatId);
                cmd.Parameters.AddWithValue("@SubId", book.SubId);
                cmd.Parameters.AddWithValue("@SubName", book.SubName);
                cmd.Parameters.AddWithValue("@SubDesc", book.SubDesc);
                cmd.Parameters.AddWithValue("@Price", book.Price);
                cmd.Parameters.AddWithValue("@Photo", book.Photo);
                cmd.Parameters.AddWithValue("@ISBN", book.ISBN);
                SqlParameter output = new SqlParameter();
                output.ParameterName = "@BookId";
                output.SqlDbType = SqlDbType.Int;
                output.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(output);
                con.Open();
                cmd.ExecuteNonQuery();
                return output.Value.ToString();

            }
        }

        public string InsertBookTitle(BookTitle book)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<BookTitle> books = new List<BookTitle>();
                SqlCommand cmd = new SqlCommand("spAddBookTitle", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@BookTitle", book.Title);
                con.Open();
                cmd.ExecuteNonQuery();
                return "Inserted Successfully";

            }

        }

        public string MakeFeatureBook(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spMakeFeatureBooks", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@BookId", id);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Feature";
            }
        }

        public string MakeHidden(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spMakesHidden", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@BookId", id);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Feature";
            }
        }

        public string MakeNonFeaturedBook(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spRemoveFromFeatureBooks", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@BookId", id);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Activated Successfully";
            }
        }

        public string MakeVisible(int id)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {

                SqlCommand cmd = new SqlCommand("spMakesVisible", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@BookId", id);
                con.Open();
                cmd.ExecuteNonQuery();

                return "Feature";
            }
        }

        public string UpdateBook(int id,BookSubCategory book)
        {
            using (SqlConnection con = new SqlConnection(Cs))
            {
                List<BookTitle> books = new List<BookTitle>();
                SqlCommand cmd = new SqlCommand("spUpdateBook", con);
                cmd.CommandType = CommandType.StoredProcedure;
               
                cmd.Parameters.AddWithValue("@SubName", book.SubName);
                cmd.Parameters.AddWithValue("@SubDesc", book.SubDesc);
                cmd.Parameters.AddWithValue("@Price", book.Price);
                cmd.Parameters.AddWithValue("@Photo", book.Photo);
                cmd.Parameters.AddWithValue("@ISBN", book.ISBN);
                cmd.Parameters.AddWithValue("@BookId", id);
                con.Open();
                cmd.ExecuteNonQuery();
                return "updated Successfully";

            }
        }
    }
}