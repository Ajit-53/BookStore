﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CapstoneApi.Books;
using System.Web.Http.Cors;

namespace CapstoneApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class BooksController : ApiController
    {
        private IBookRepository repository;
       
        public BooksController()
        {
            repository = new BookImplementation();
        }

        [HttpGet]
        [Route("GetBookCat")]
        public IHttpActionResult GetBookCat()
        {
            var data = repository.GetBookCategories();
            return Ok(data);
        }
        [HttpGet]
        [Route("GetBookTitle")]
        public IHttpActionResult GetBookTitle()
        {
            var data = repository.GetBookTitles();
            return Ok(data);
        }

        [HttpGet]
        [Route("GetBookSubCat")]
        public IHttpActionResult GetBookSubCategorywithStatus()
        {
            var data = repository.GetBookSubCategories();
            return Ok(data);
        }


        [HttpGet]
        [Route("GetBookSubCatpagebypage/{pageno}")]
        public IHttpActionResult GetBookSubCategorypagebypage(int pageno)
        {
            var data = repository.GetBookSubCategoriesbyPage(pageno);
            return Ok(data);
        }

        [HttpGet]
        [Route("GetBookSubCat/CatId/{id}")]
        public IHttpActionResult GetBookSubCategorybyCatId(int id)
        {
            var data = repository.GetBookSubCategoriesbyCatId(id);
            return Ok(data);
        }


        [HttpGet]
        [Route("GetBookCat/{id}")]
        public IHttpActionResult GetBookCategorybyCatId(int id)
        {
            var data = repository.GetBookCategoriesbyCatId(id);
            return Ok(data);
        }

        [HttpGet]
        [Route("GetBookSubCat/SubId/{id}")]
        public IHttpActionResult GetBookSubCategorybySubId(int id)
        {
            var data = repository.GetBookSubCategoriesbySubId(id);
            return Ok(data);
        }


        [HttpGet]
        [Route("GetBooksSubCat/{id}")]
        public IHttpActionResult GetBookSubCategorybyId(int id)
        {
            var data = repository.GetBookSubCategorybyId(id);
            return Ok(data);
        }

        [HttpGet]
        [Route("GetBookSubCat/Alphabatically")]
        public IHttpActionResult GetBookSubCategoryAlphabatically()
        {
            var data = repository.GetBookSubCategoriesAlphabatically();
            return Ok(data);
        }


        [HttpGet]
        [Route("GetFeaturedBook")]
        public IHttpActionResult GetFeaturedBook()
        {
            var data = repository.GetFeaturedBook();
            return Ok(data);
        }

        [HttpGet]
        [Route("GetZeroStatusBook")]
        public IHttpActionResult GetZeroStatusBook()
        {
            var data = repository.GetBookSubCategorieswithZeroStatus();
            return Ok(data);
        }

        [HttpGet]
        [Route("GetBookSubCat/PriceInc")]
        public IHttpActionResult GetBookSubCategoryPriceInc()
        {
            var data = repository.GetBookSubCategoriesbyPriceInc();
            return Ok(data);
        }
        [HttpGet]
        [Route("GetBookSubCat/PriceDesc")]
        public IHttpActionResult GetBookSubCategorybyPriceDesc()
        {
            var data = repository.GetBookSubCategoriesbyPriceDesc();
            return Ok(data);
        }


        [HttpPost]
        [Route("AddBookTitle")]
        public HttpResponseMessage InsertBookTitle(BookTitle book)
        {
            var row = repository.InsertBookTitle(book);
            if (row ==null )
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpPost]
        [Route("AddBookCategory")]
        public HttpResponseMessage InsertBookCat(BookCategory book)
        {
            var row = repository.InsertBookCategory(book);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpPost]
        [Route("AddBookSubCategory")]
        public HttpResponseMessage InsertBookSubCat(BookSubCategory book)
        {
            var row = repository.InsertBookSubCategory(book);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpPut]
        [Route("ActivateBook/{id}")]
        public HttpResponseMessage ActivateBook(int id)
        {
            var row = repository.ActivateBook(id);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpPut]
        [Route("DeactivateBook/{id}")]
        public HttpResponseMessage DeactivateBook(int id)
        {
            var row = repository.DeactivateBook(id);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }


        [HttpPut]
        [Route("MakeFeature/{id}")]
        public HttpResponseMessage MakeFeatureBook(int id)
        {
            var row = repository.MakeFeatureBook(id);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpPut]
        [Route("MakeVisible/{id}")]
        public HttpResponseMessage MakeVisibleBook(int id)
        {
            var row = repository.MakeVisible(id);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }


        [HttpPut]
        [Route("MakeHidden/{id}")]
        public HttpResponseMessage MakeBookHidden(int id)
        {
            var row = repository.MakeHidden(id);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpPut]
        [Route("MakeNonFeature/{id}")]
        public HttpResponseMessage MakeNonFeatureBook(int id)
        {
            var row = repository.MakeNonFeaturedBook(id);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpPut]
        [Route("Update/{id}")]
        public HttpResponseMessage UpdateBook(int id, BookSubCategory book)
        {
            var row = repository.UpdateBook(id, book);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpDelete]
        [Route("DeleteBook/{id}")]
        public HttpResponseMessage DeleteBook(int id)
        {
            var row = repository.DeleteBook(id);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

    }
}
