﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using CapstoneApi.User;

namespace CapstoneApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class ApplicationUserController : ApiController
    {
        private IUserRepository repository;

        public ApplicationUserController()
        {

            repository = new UserImplementation();
        }
        [HttpPost]
        [Route("AddUser")]
        public HttpResponseMessage InsertUser(RegisterUser user)
        {
            var row = repository.AddUser(user);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpPost]
        [Route("AddToCart")]
        public HttpResponseMessage AddToCart(Cart cart)
        {
            var row = repository.AddToCart(cart);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpPost]
        [Route("AddToWhislist")]
        public HttpResponseMessage AddToWhislist(Cart cart)
        {
            var row = repository.AddToWhislist(cart);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpPost]
        [Route("AdminLogin")]
        public IHttpActionResult AdminLogin(LoginAdmin admin)
        {
            var data = repository.Loginadmin(admin);
            return Ok(data);
        }

        [HttpGet]
        [Route("CartCount/{id}")]
        public IHttpActionResult CartCount(int id)
        {
            var data = repository.CartItemCount(id);
            return Ok(data);
        }

        [HttpGet]
        [Route("WhislistCount/{id}")]
        public IHttpActionResult WhislistCount(int id)
        {
            var data = repository.WhislistItemCount(id);
            return Ok(data);
        }

        [HttpGet]
        [Route("GetCartItem/{id}")]
        public IHttpActionResult GetCartItem(int id)
        {
            var data = repository.GetCartItemByUserId(id);
            return Ok(data);
        }

        [HttpGet]
        [Route("GetWhislistItem/{id}")]
        public IHttpActionResult GetWhislistItem(int id)
        {
            var data = repository.GetWhislistItemsByUserId(id);
            return Ok(data);
        }

        [HttpPost]
        [Route("UserLogin")]
        public IHttpActionResult UserLogin(LoginUser user)
        {
            var data = repository.Loginuser(user);
            return Ok(data);
        }

        [HttpDelete]
        [Route("DeleteCartBook/{id}")]
        public HttpResponseMessage DeleteCartBook(int id)
        {
            var row = repository.DeleteFromCart(id);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }


        [HttpDelete]
        [Route("DeleteWhislistBook/{id}")]
        public HttpResponseMessage DeleteWhislistBook(int id)
        {
            var row = repository.DeleteFromWhislist(id);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpPut]
        [Route("UpdateCartItemQuant/{id}/{quant}")]
        public HttpResponseMessage UpdateCartItemQuantity(int id,int quant)
        {
            var row = repository.UpdateItemQuantInCart(quant, id);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }
    }
}
