﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CapstoneApi.Books;
using System.Web.Http.Cors;
using CapstoneApi.Admin;

namespace CapstoneApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class AdminController : ApiController
    {
        private IAdminRepository repository;

        public AdminController()
        {

            repository = new CouponImplementation();
        }

        [HttpPut]
        [Route("DeactivateCoupon/{coupon}")]
        public HttpResponseMessage DeactivateCoupons(string coupon)
        {
            var row = repository.DeactvateCoupons(coupon);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }


        [HttpPut]
        [Route("ActivateUser/{id}")]
        public HttpResponseMessage ActivateUser(int id)
        {
            var row = repository.ActivateUser(id);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpPut]
        [Route("BlockUser/{id}")]
        public HttpResponseMessage DeactivateUser(int id)
        {
            var row = repository.BlockUser(id);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpPut]
        [Route("ActivateCoupon/{coupon}")]
        public HttpResponseMessage ActivateCoupons(string coupon)
        {
            var row = repository.ActivateCoupon(coupon);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }

        [HttpGet]
        [Route("GetCoupons/{id}")]
        public IHttpActionResult GetCouponsById(int id)
        {
            var data = repository.GetCouponById(id);
            return Ok(data);
        }

        [HttpGet]
        [Route("GetActivatedCoupons")]
        public IHttpActionResult GetActivatedCoupons()
        {
            var data = repository.GetActivatedCoupons();
            return Ok(data);
        }


        [HttpGet]
        [Route("GetBlockedUser")]
        public IHttpActionResult GetBlockedUser()
        {
            var data = repository.GetBlockedUser();
            return Ok(data);
        }

        [HttpGet]
        [Route("GetCoupons")]
        public IHttpActionResult GetCoupons()
        {
            var data = repository.GetCoupon();
            return Ok(data);
        }

        [HttpPost]
        [Route("AddCoupon")]
        public HttpResponseMessage InsertCoupon(AddCoupon coupon)
        {
            var row = repository.InsertCoupon(coupon);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }


        [HttpGet]
        [Route("GetCouponss")]
        public HttpResponseMessage GetActivateCoupons(string coupon)
        {
            var row = repository.ActivateCoupon(coupon);
            if (row == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong");
            }
            return Request.CreateResponse(HttpStatusCode.Created, "Record inserted ");
        }


        



    }
}
