import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-cart',
  templateUrl: './home-cart.component.html',
  styleUrls: ['./home-cart.component.scss']
})
export class HomeCartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
