import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-checkout',
  templateUrl: './home-checkout.component.html',
  styleUrls: ['./home-checkout.component.scss']
})
export class HomeCheckoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
