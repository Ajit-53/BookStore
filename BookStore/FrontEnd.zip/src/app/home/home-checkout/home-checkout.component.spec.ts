import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeCheckoutComponent } from './home-checkout.component';

describe('HomeCheckoutComponent', () => {
  let component: HomeCheckoutComponent;
  let fixture: ComponentFixture<HomeCheckoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HomeCheckoutComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeCheckoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
