import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HomeService {
url='http://localhost:51169/';
  constructor(public http:HttpClient) { }
GetFeaturedBook():Observable<any>
{
   return this.http.get<any>(this.url+'GetFeaturedBook');
}
}
