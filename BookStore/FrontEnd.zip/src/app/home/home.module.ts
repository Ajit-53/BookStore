import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home.component';
import { SharedModule } from '../shared/shared.module';
import { CoreModule } from '../core/core.module';

import { MainComponent } from './main/main.component';
import { IconsComponent } from './icons/icons.component';

import { NewsletterComponent } from './newsletter/newsletter.component';
import { ArrivalComponent } from './arrival/arrival.component';
import { DealComponent } from './deal/deal.component';
import { FooterComponent } from './footer/footer.component';
import { HomeHeaderComponent } from './home-header/home-header.component';
import { LoaderComponent } from './loader/loader.component';
import { ReviewComponent } from './review/review.component';

import { HomeLoginComponent } from './home-login/home-login.component';
import { HomeRegisterComponent } from './home-register/home-register.component';
import { HomeCartComponent } from './home-cart/home-cart.component';
import { HomeCheckoutComponent } from './home-checkout/home-checkout.component';
import { FormsModule } from '@angular/forms';

import { MatCardModule } from '@angular/material/card';
import { CarouselModule } from 'ngx-owl-carousel-o';



@NgModule({
  declarations: [
    HomeComponent,

    MainComponent,
    IconsComponent,

    NewsletterComponent,
    ArrivalComponent,
    DealComponent,
    FooterComponent,
    HomeHeaderComponent,
    LoaderComponent,
    ReviewComponent,

    HomeLoginComponent,
      HomeRegisterComponent,
      HomeCartComponent,
      HomeCheckoutComponent,
    
    

  ],
  imports: [
    CommonModule,
    SharedModule,
    CoreModule,
    FormsModule,
    MatCardModule,
    CarouselModule
  ],
  exports:[HomeComponent, HomeHeaderComponent]
})
export class HomeModule { }
