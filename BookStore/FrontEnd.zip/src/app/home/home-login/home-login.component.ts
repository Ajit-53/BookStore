import { Component, OnInit } from '@angular/core';
import { AppService } from 'src/app/app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-login',
  templateUrl: './home-login.component.html',
  styleUrls: ['./home-login.component.scss']
})
export class HomeLoginComponent implements OnInit {
  public userModel=
  {
    username:null,
    password:null
  }
  message:any
  data:any
  message1:any
  data1:any
    constructor(public auth:AppService,public router:Router) { }
  
    ngOnInit(): void {
    }

  onchange(Data:any)
  {
    this.data1=Data.value;
  }
  onSubmit(data:any){
    if(this.data1==='Admin'){
    this.auth.AdminLogin(this.userModel).subscribe(response => {
      this.data=response;
      if(response!=null)
      {
      localStorage.setItem('admin',JSON.stringify(response.username));
      this.message='Login Successfully'
      this.router.navigateByUrl('/admin')
      }
      else
      {
      this.message1='Invalid Credentials'
            this.router.navigateByUrl('/userlogin')
      }
    });  
  }
  if(this.data1==='User'){
    this.auth.UserLogin(this.userModel).subscribe(response => {
      this.data=response;
      if(response!=null)
      {
      localStorage.setItem('user',JSON.stringify(response));
      //console.log(response.Username);
      this.message='Login Successfully'
      this.router.navigateByUrl('/shop')
      }
      else
      {
      this.message1='Either You are Blocked by Admin or Invalid Credentials'
            this.router.navigateByUrl('/userlogin')
      }
    });  
  }
       
  }
}
