import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
defaultAmount:number=0;
constructor() { }
private TotalAmount = new BehaviorSubject(this.defaultAmount);
latestTotalAmount: Observable<any> = this.TotalAmount.asObservable();

 
  GetDefaultTotal(defaulttotal:number)
  {
  this.defaultAmount=defaulttotal;
  
  
  // const newCartItemsArr = [ ...cartItems, pdt ];
  // console.log(newCartItemsArr);
   this.TotalAmount.next(this.defaultAmount);
   console.log(this.TotalAmount);
  }
}
