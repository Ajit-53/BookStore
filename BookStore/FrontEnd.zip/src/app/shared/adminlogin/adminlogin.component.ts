import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.scss']
})
export class AdminloginComponent implements OnInit {

  public userModel=
  {
    username:null,
    password:null
  }
  message:any
  data:any
  message1:any
  data1:any
    constructor(public auth:AppService,public router:Router) { }
  
    ngOnInit(): void {
    }
    onchange(Data:any)
    {
      this.data1=Data.value;
    }
    onSubmit(data:any){
      if(this.data1==='Admin'){
      this.auth.AdminLogin(this.userModel).subscribe(response => {
        this.data=response.username;
        // console.log(response);
        if(response.username!=null)
        {
        localStorage.setItem('admin',JSON.stringify(response.username));
        this.message='Login Successfully'
        this.router.navigateByUrl('/admin')
        }
        else
        {
        this.message='Invalid Credentials'
        this.userModel.username=null;
        this.userModel.password=null;
        this.router.navigateByUrl('/login')
        }
      });  
    }
    if(this.data1==='User'){
      this.auth.UserLogin(this.userModel).subscribe(response => {
        this.data=response.Username;
        console.log(response);
        if(response.Username!=null)
        {
        localStorage.setItem('user',JSON.stringify(response.Username));
        console.log(response.Username);
        this.message='Login Successfully'
        this.router.navigateByUrl('/home')
        }
        else
        {
        this.message='Invalid Credentials'
        this.userModel.username=null;
        this.userModel.password=null;
        this.router.navigateByUrl('/login')
        }
      });  
    }
         
    }
}
