import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { RouterModule } from '@angular/router';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { FormsModule } from '@angular/forms';
import { OrdersummaryComponent } from './ordersummary/ordersummary.component';
import {CdkStepperModule} from '@angular/cdk/stepper';
import { StepperComponent } from './stepper/stepper.component';





@NgModule({
  declarations: [HeaderComponent,AdminloginComponent, OrdersummaryComponent,StepperComponent],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    CdkStepperModule

  ],
  exports:[HeaderComponent,OrdersummaryComponent,CdkStepperModule,StepperComponent]
})
export class SharedModule { }
