import { Component, Input, OnInit } from '@angular/core';
import { BasketService } from 'src/app/basket/basket.service';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-ordersummary',
  templateUrl: './ordersummary.component.html',
  styleUrls: ['./ordersummary.component.scss']
})
export class OrdersummaryComponent implements OnInit {

shipping:number=50;
coupondiscount:number=0;
total:number=0;


  constructor(public basketservice:BasketService,public sharedservice:SharedService) {
    
    console.log("inside ordersummary constructor");
   
   
   }

  ngOnInit(): void {
    this.basketservice.CouponDiscount.subscribe(res=>{
      this.coupondiscount=res;
    })
    this.basketservice.ShippingCost.subscribe(res=>{
      this.shipping=res;
    })
    this.basketservice.TotalAmount.subscribe(res=>{
      this.total=res;
      console.log(this.total);
    })
   console.log("inside ngOnInit")
  }

}
