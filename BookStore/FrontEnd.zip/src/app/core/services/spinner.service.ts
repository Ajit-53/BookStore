import { Injectable } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';

@Injectable({
  providedIn: 'root'
})
export class SpinnerService {
RequestCount=0;
  constructor(private spinner:NgxSpinnerService) { }
  busy(){
    this.RequestCount++;
    this.spinner.show(undefined,{
      type:'square-loader',
      bdColor:'rgba(255,255,255,0.7)',
      color:'#333356'
    });
  }

  idle(){
    this.RequestCount--;
    if(this.RequestCount<=0){
      this.RequestCount=0;
      this.spinner.hide();
    }
  }
}
