import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { BasketService } from 'src/app/basket/basket.service';
import { ShopService } from 'src/app/shop/shop.service';
import { CoreService } from '../core.service';

@Component({
  selector: 'app-whislist',
  templateUrl: './whislist.component.html',
  styleUrls: ['./whislist.component.scss']
})
export class WhislistComponent implements OnInit {
user1:any
items:any
userId:any
cartcount:any
x:any
item={
  userid:null,
  itemname:null,
  itemprice:null,
  itemid:null,
  itemdesc:null,
  // itemurl:'abc',
  itemquant:1
}
  constructor(public whislistservice:CoreService,public shopservice:ShopService,public appservice:AppService,public route:Router) { 
      this.shopservice.BasketCount.subscribe((res)=>{
        this.cartcount=res;
      })
  }

  ngOnInit(): void {
    this.GetWhislistItems();
    console.log("whislist works")
  }

  GetWhislistItems()
  {
    this.user1=localStorage.getItem('user');
    this.whislistservice.GetWhislistItemsByUserId( JSON.parse(this.user1).UserId).subscribe((res)=>{
      this.items=res;
    })
  }
  AddToCart(data:any)
  {
    
    if(this.appservice.UserloggedIn())
    {  
      this.user1=localStorage.getItem('user');
      this.item.userid=JSON.parse(this.user1).UserId;
      this.item.itemname=data.ItemName;
      this.item.itemprice=data.ItemPrice;
      this.item.itemdesc=data.ItemDesc;
      this.item.itemid=data.ItemId;
      this.item.itemquant=1;
console.log(this.item);

      this.whislistservice.GetCartCount(JSON.parse(this.user1).UserId).subscribe((res=>{
        this.cartcount=res;
        this.x=++this.cartcount;
        console.log(this.x);
        this.shopservice.BasketCount.next(this.x);}))
     
      
      
      this.shopservice.AddToCart(this.item).subscribe();
     
      // alert("Hello\nHow are you?");
      // this.route.navigateByUrl('/shop');

    }else
    {
     this.route.navigateByUrl('/userlogin');
    }
  }
  OnDelete(BookId:number)
  {
     alert("Are You Sure?")
     this.whislistservice.DeleteFromWhislist(BookId).subscribe();
  }

}
