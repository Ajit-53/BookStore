import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CoreService {

CartCount=new Subject<any>();


url='http://localhost:51169/'
  constructor(public http:HttpClient) { }
GetCartCount(id:number):Observable<any>{
  return this.http.get<any>(this.url+'CartCount/'+id);
}
GetWhislistCount(id:number):Observable<any>{
  return this.http.get<any>(this.url+'WhislistCount/'+id);
}
GetWhislistItemsByUserId(UserId:number):Observable<any>
  {
    return this.http.get<any>(this.url+'GetWhislistItem/'+UserId)
  }
DeleteFromWhislist(Bookid:number):Observable<any>
{
  return this.http.delete<any>(this.url+'DeleteWhislistBook/'+Bookid);
}  

}
