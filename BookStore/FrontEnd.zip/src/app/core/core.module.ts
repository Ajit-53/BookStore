import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from './navbar/navbar.component';
import { RouterModule } from '@angular/router';
import { BasketModule } from '../basket/basket.module';
import { WhislistComponent } from './whislist/whislist.component';




@NgModule({
  declarations: [NavbarComponent, WhislistComponent],
  imports: [
    CommonModule,
    RouterModule,
    BasketModule

  ],
  exports:[NavbarComponent]
})
export class CoreModule { }
