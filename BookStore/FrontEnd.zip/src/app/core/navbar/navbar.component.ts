import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { CoreService } from '../core.service';
import { ShopService } from 'src/app/shop/shop.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {

 
 cartcount:any
 whislistcount:any
 userId:any
 message=''

  constructor(public service:AppService,public route:Router,public coreservice:CoreService,public shopservice:ShopService) { 
   
  }

  ngOnInit(): void {
    if(this.service.UserloggedIn()){
     this.userId=localStorage.getItem('user');
     this.message=JSON.parse(this.userId).Username;
      this.coreservice.GetCartCount(JSON.parse(this.userId).UserId).subscribe((res=>{
        this.cartcount=res;
      }))
      this.coreservice.GetWhislistCount(JSON.parse(this.userId).UserId).subscribe((res)=>{
        this.whislistcount=res;
      })
    this.shopservice.BasketCount.subscribe((res)=>{
      this.cartcount=res;
    })
    this.shopservice.WhislistCount.subscribe((res)=>{
      this.whislistcount=res;
    })
    }else{
      this.cartcount=0;
      this.whislistcount=0;
    }
  }
  // onclick()
  // {
  //   this.count++;
  // }
  

}
