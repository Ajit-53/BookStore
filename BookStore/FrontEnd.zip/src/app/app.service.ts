import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  private ENDPOINTS = {
   ADMIN_LOGIN_URL:'http://localhost:51169/AdminLogin',
   USER_LOGIN_URL:'http://localhost:51169/UserLogin'
  }

  constructor(private http: HttpClient) { }


  AdminLogin(data: any): Observable<any>{
    return this.http.post<any>(this.ENDPOINTS.ADMIN_LOGIN_URL, data)
  }
  UserLogin(data: any): Observable<any>{
    return this.http.post<any>(this.ENDPOINTS.USER_LOGIN_URL, data)
  }
  
  
  Adminlogout(){
    localStorage.removeItem('admin');
  }
  Userlogout(){
    localStorage.removeItem('user');
  }
  AdminloggedIn(): boolean{
    if(localStorage.getItem('admin')){
      return true;
    }else{
      return false;
    }
  }
  UserloggedIn(): boolean{
    if(localStorage.getItem('user')){
      return true;
    }else{
      return false;
    }
  }
}
