import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ShopService {
Url='http://localhost:51169/'

BasketCount=new Subject<any>();
WhislistCount=new Subject<any>();

  constructor(public http:HttpClient) { }

  GetCategorywithTitle(): Observable<any>{
    return this.http.get<any>(this.Url+'GetBookCat')
  }
  GetwithTitle(): Observable<any>{
    return this.http.get<any>(this.Url+'GetBookTitle')
  }
  GetSubCategorywithTitle(CatId?:any,SubId?:any): Observable<any>{
    // let params = new HttpParams();
    // if(CatId)
    // {
    //   params=params.append('CatId',CatId.toString());
    // }
    // if(SubId)
    // {
    //   params=params.append('SubId',SubId.toString());
    // }
    return this.http.get<any>(this.Url+'GetBookSubCat')
    // .pipe(
    //   map((response: { body: any; })=>{
    //     console.log(response);
    //     return response.body;
      
    //   })
    // )
  }

  GetSubCategorybySubId(SubId:any)
  {
    return this.http.get<any>(this.Url+'GetBookSubCat/SubId/'+SubId);
  }

  GetSubCategorybyCatId(CatId:any)
  {
    return this.http.get<any>(this.Url+'GetBookSubCat/CatId/'+CatId);
  }
  GetSubCategorybyId(Id:any)
  {
    return this.http.get<any>(this.Url+'GetBooksSubCat/'+Id);
  }

  GetSubCategoryAlphabatically()
  {
    return this.http.get<any>(this.Url+'GetBookSubCat/Alphabatically');
  }

  GetSubCategorybyPriceInc()
  {
    return this.http.get<any>(this.Url+'GetBookSubCat/PriceInc');
  }

 
  GetSubCategorybyPriceDesc()
  {
    return this.http.get<any>(this.Url+'GetBookSubCat/PriceDesc');
  }

  AddToCart(data:any):Observable<any>
  {
     return this.http.post<any>(this.Url+'AddToCart',data);
  }
  AddToWhislist(data:any):Observable<any>
  {
    return this.http.post<any>(this.Url+'AddToWhislist',data);
  }
  // GetByPage(pageno:number):Observable<any>
  // {
  //   return this.http.get<any>(this.Url+'GetBookSubCatpagebypage/'+pageno);
  // }
}
