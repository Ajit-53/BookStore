import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { CoreService } from 'src/app/core/core.service';
import { ShopService } from '../shop.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss']
})
export class ProductDetailsComponent implements OnInit {
bookid:any
product:any
cartcount:any
x:any
user1:any
item={
  userid:null,
  itemname:null,
  itemprice:null,
  itemid:null,
  itemdesc:null,
  // itemurl:'abc',
  itemquant:1
}
  constructor(private activateRoute:ActivatedRoute,private shopservice:ShopService,private appservice:AppService,
    private whislistservice:CoreService,private route:Router) { 
    this.bookid = activateRoute.snapshot.paramMap.get('id');
  }

  ngOnInit(): void {
    this.shopservice.GetSubCategorybyId(this.bookid).subscribe((res)=>{
      this.product=res;
      console.log(this.product);
    })
  }
  AddToCart(data:any)
  {
    
    if(this.appservice.UserloggedIn())
    {  
      this.user1=localStorage.getItem('user');
      this.item.userid=JSON.parse(this.user1).UserId;
      this.item.itemname=data.SubName;
      this.item.itemprice=data.Price;
      this.item.itemdesc=data.SubDesc;
      this.item.itemid=data.Id;
      this.item.itemquant=1;
console.log(this.item);

      this.whislistservice.GetCartCount(JSON.parse(this.user1).UserId).subscribe((res=>{
        this.cartcount=res;
        this.x=++this.cartcount;
        console.log(this.x);
        this.shopservice.BasketCount.next(this.x);}))
     
      
      
      this.shopservice.AddToCart(this.item).subscribe();
     
      // alert("Hello\nHow are you?");
      // this.route.navigateByUrl('/shop');

    }else
    {
     this.route.navigateByUrl('/userlogin');
    }
  }



}
