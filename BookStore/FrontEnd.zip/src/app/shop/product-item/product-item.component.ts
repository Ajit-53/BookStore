import { Component, Input, OnInit } from '@angular/core';
import { AppService } from 'src/app/app.service';
import { Router } from '@angular/router';
import { ShopService } from '../shop.service';
import { CoreService } from 'src/app/core/core.service';

@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.scss']
})
export class ProductItemComponent implements OnInit {
  price=50
  user1:any
  basketcount:any
  wishlistcount:any
  x:any
  item={
    userid:null,
    itemname:null,
    itemprice:null,
    itemid:null,
    itemdesc:null,
    // itemurl:'abc',
    itemquant:1
  }
  whislistitem={
    userid:null,
    itemname:null,
    itemprice:null,
    itemid:null,
    itemdesc:null,
    
  }
  @Input() product:any;
  constructor(public service:AppService,public route :Router,public shopservice:ShopService,public coreservice:CoreService) { 
    this.shopservice.BasketCount.subscribe((res)=>{
      this.basketcount=res;
    })
    this.shopservice.WhislistCount.subscribe((res)=>{
      this.wishlistcount=res;
    })
  }

  ngOnInit(): void {
    // this.user1=localStorage.getItem('user');
    //   console.log(this.user1);
  }

  onclick(data:any){
  

    if(this.service.UserloggedIn())
    {  
      this.user1=localStorage.getItem('user');
      this.item.userid=JSON.parse(this.user1).UserId;
      this.item.itemname=data.SubName;
      this.item.itemprice=data.Price;
      this.item.itemdesc=data.SubDesc;
      this.item.itemid=data.Id;
      this.item.itemquant=1;


      this.coreservice.GetCartCount(JSON.parse(this.user1).UserId).subscribe((res=>{
        this.basketcount=res;
        this.x=++this.basketcount;
        console.log(this.x);
        this.shopservice.BasketCount.next(this.x);}))
     
      
      
      this.shopservice.AddToCart(this.item).subscribe();
     
      // alert("Hello\nHow are you?");
      // this.route.navigateByUrl('/shop');

    }else
    {
     this.route.navigateByUrl('/userlogin');
    }
  }

  onclick1(data:any){
    
    if(this.service.UserloggedIn())
    {  
      this.user1=localStorage.getItem('user');
      this.whislistitem.userid=JSON.parse(this.user1).UserId;
      this.whislistitem.itemname=data.SubName;
      this.whislistitem.itemprice=data.Price;
      this.whislistitem.itemdesc=data.SubDesc;
      this.whislistitem.itemid=data.Id;
      
      this.coreservice.GetWhislistCount(JSON.parse(this.user1).UserId).subscribe((res=>{
        this.wishlistcount=res;
        this.x=++this.wishlistcount;
        console.log(this.x);
        this.shopservice.WhislistCount.next(this.x);}))
     
      
      
      this.shopservice.AddToWhislist(this.whislistitem).subscribe();}
     else
    {
     this.route.navigateByUrl('/userlogin');
    }
  }
  onclick2(id:any){
    console.log(id);
    this.route.navigate(['shop',id])
  }
  

}
