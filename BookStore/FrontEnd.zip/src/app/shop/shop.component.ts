import { Component, OnInit } from '@angular/core';
import { ShopService } from './shop.service';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.scss']
})
export class ShopComponent implements OnInit {
data:any
Items:any
Items1:any
CatIdSelected:any
SubIdSelected:any
// items:any[]=[1,2,3,4,5,6,7,8,9]

  constructor(public service:ShopService) { }

  ngOnInit(): void {
   this.GetBooks();
   this.GetCategory();
   this.GetSubCategory(); 

  }

  GetBooks()
  {
    this.service.GetCategorywithTitle().subscribe((response)=>{
      this.data=response;
      // console.log(this.data);
    })

   
  }

  GetCategory()
  {
    this.service.GetwithTitle().subscribe((response)=>{
      this.Items=response;
       console.log(this.Items);
    })
  }

  GetSubCategory()
  {
     this.service.GetSubCategorywithTitle().subscribe((response)=>{
      this.Items1=response;
      
    })
    
   
  }

  OnBookSelected(CatId:any)
  {
    this.CatIdSelected=CatId;
    // this.GetSubCategory();
     console.log(CatId);
    this.service.GetSubCategorybyCatId(CatId).subscribe((response)=>{
      this.Items1=response;
    // console.log(response);
  })
      

  }

  OnCategorySelected(SubId:any)
  {
     this.SubIdSelected=SubId;
    // this.GetSubCategory();
    this.service.GetSubCategorybySubId(SubId).subscribe((response)=>{
      this.Items1=response;
    })
  }

  onchange(Data:any){
    if(Data.value==='A')
    {
      this.service.GetSubCategoryAlphabatically().subscribe((response)=>{
        this.Items1=response;
      })
    }
    if(Data.value==='L')
    {
      this.service.GetSubCategorybyPriceInc().subscribe((response)=>{
        this.Items1=response;
      })
    }
    if(Data.value==='P')
    {
      this.service.GetSubCategorybyPriceDesc().subscribe((response)=>{
        this.Items1=response;
      })
    }

  }

//  myFunction() {
//     var input, filter, table, tr, td, i, txtValue;
//     input = document.getElementById("myInput");
//    filter = input.value.toUpperCase();
//     table = document.getElementById("myTable");
//     tr = table.getElementsByTagName("tr");
//     for (i = 0; i < tr.length; i++) {
//       td = tr[i].getElementsByTagName("td")[0];
//       if (td) {
//         txtValue = td.textContent || td.innerText;
//         if (txtValue.toUpperCase().indexOf(filter) > -1) {
//           tr[i].style.display = "";
//         } else {
//           tr[i].style.display = "none";
//         }
//       }       
//     }
//   }
  
// onclick(item:any){
//   this.pageno=item;
//   this.service.GetByPage(item).subscribe((response)=>{
//     this.Items1=response;})
// }




  
}
