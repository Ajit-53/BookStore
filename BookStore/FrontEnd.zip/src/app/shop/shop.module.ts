import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductItemComponent } from './product-item/product-item.component';
import { ShopComponent } from './shop.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { RouterModule } from '@angular/router';
import { ShopRoutingModule } from './shop-routing.module';
import { SharedModule } from '../shared/shared.module';
import { CoreModule } from '../core/core.module';
import { HttpClientModule } from '@angular/common/http';
import { DemoComponent } from './demo/demo.component';



@NgModule({
  declarations: [ShopComponent,ProductItemComponent, ProductDetailsComponent, DemoComponent],
  imports: [
    CommonModule,
    RouterModule,
    ShopRoutingModule,
    SharedModule,
    CoreModule,
    HttpClientModule
  
  ],
  // exports:[ShopComponent]
})
export class ShopModule { }
