import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { AdminService } from 'src/app/admin/admin.service';
import { BasketService } from '../basket.service';

@Component({
  selector: 'app-basket-coupon',
  templateUrl: './basket-coupon.component.html',
  styleUrls: ['./basket-coupon.component.scss']
})
export class BasketCouponComponent implements OnInit {

  posts1:any
  coupondiscount:number=0;
  constructor(public adminservice:AdminService,public dialogref:MatDialogRef<BasketCouponComponent>,public basketservice:BasketService) { 
    this.basketservice.CouponDiscount.subscribe(res=>{
      this.coupondiscount=res;
    })
  }

  
  
  ngOnInit(): void {
    this.GetCoupon();
    
  }
  GetCoupon()
  {
    this.adminservice.GetActivatedCoupon().subscribe((res)=>{
      this.posts1=res;
    })
  }
  onchange(Data:any)
  {
    this.coupondiscount=parseInt(Data.value);
    console.log(typeof(this.coupondiscount));
  }

 Onsubmit(){
  this.basketservice.CouponDiscount.next(this.coupondiscount);
  this.onclose();

 } 

 onclose(){
this.dialogref.close();
 }

}
