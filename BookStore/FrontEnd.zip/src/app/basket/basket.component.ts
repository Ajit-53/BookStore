import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../app.service';
import { CoreService } from '../core/core.service';
import { BasketService } from './basket.service';
import {MatDialog} from '@angular/material/dialog';
import { BasketCouponComponent } from './basket-coupon/basket-coupon.component';
import { BasketShippingOptionsComponent } from './basket-shipping-options/basket-shipping-options.component';
import { SharedService } from '../shared/shared.service';

@Component({
  selector: 'app-basket',
  templateUrl: './basket.component.html',
  styleUrls: ['./basket.component.scss']
})
export class BasketComponent implements OnInit {
items:any
user1:any
count:any
userId:any
message=''
name:any
count1:number=1;
a:any
b:any
TotalAmount:number=0;
     
  constructor(public basketservice:BasketService,public service:AppService,public route:Router,public coreservice:CoreService,
    public dialog:MatDialog,public sharedservice:SharedService) { 
      this.basketservice.TotalAmount.subscribe(res=>{
        this.TotalAmount=res;
      })
    }

  ngOnInit(): void {
    this.GetCartItems();
    this.GetAuthenticate();
    
  }
  GetCartItems()
  {
    this.user1=localStorage.getItem('user');
    this.basketservice.GetCatItemsByUserId( JSON.parse(this.user1).UserId).subscribe((res)=>{
      this.items=res;
      for(let i=0;i<this.items.length;i++ ){
        this.TotalAmount=this.TotalAmount+ this.items[i].ItemQuant*this.items[i].ItemPrice;
      }
      // this.sharedservice.GetDefaultTotal(this.TotalAmount);
      this.basketservice.TotalAmount.next(this.TotalAmount);
     
    
    })
  }

  
  
    

  OnDelete(BookId:number)
  {
    alert("Are you Sure?")
    this.basketservice.DeleteBook(BookId).subscribe();

  }
  GetAuthenticate()
  {
    if(this.service.UserloggedIn()){
      this.userId=localStorage.getItem('user');
      this.message=JSON.parse(this.userId).Username;
       this.coreservice.GetCartCount(JSON.parse(this.userId).UserId).subscribe((res=>{
         this.count=res;
       }))
     }else{
       this.count=0;
     }
  }
  OnIncrement(data:any)
  {
    this.a=++data.ItemQuant;
   this.TotalAmount=this.TotalAmount+ data.ItemPrice;
   this.basketservice.TotalAmount.next(this.TotalAmount);
    this.basketservice.UpdateQuant(this.a,data.Id).subscribe(); 
    console.log(data.Id);
  }
  OnDecrement(data:any)
  {
    if(data.ItemQuant>=2)
    {
      this.b=--data.ItemQuant
       this.TotalAmount=this.TotalAmount-data.ItemPrice;
       this.basketservice.TotalAmount.next(this.TotalAmount);
       this.basketservice.UpdateQuant(this.b,data.Id).subscribe();
       console.log(data.Id);
    
  }else{
    alert("Items Cannot be Zero");
  }
  }
  onclick1()
  {
    this.dialog.open(BasketCouponComponent);
  }
  onclick2()
  {
   this.dialog.open(BasketShippingOptionsComponent)
  }

  
}






