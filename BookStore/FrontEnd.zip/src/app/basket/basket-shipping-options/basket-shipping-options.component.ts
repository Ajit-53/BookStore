import { Component, OnInit } from '@angular/core';
import { BasketService } from '../basket.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-basket-shipping-options',
  templateUrl: './basket-shipping-options.component.html',
  styleUrls: ['./basket-shipping-options.component.scss']
})
export class BasketShippingOptionsComponent implements OnInit {
shippingcharge:number=0;
  constructor(public basketservice:BasketService,public dialogref:MatDialogRef<BasketShippingOptionsComponent>) { 
    this.basketservice.ShippingCost.subscribe(res=>{
      this.shippingcharge=res;
    })
  }

  ngOnInit(): void {
  }
  Onsubmit()
  {
    this.basketservice.ShippingCost.next(this.shippingcharge);
    this.onclose();
  }
  onchange(data:any)
  {
    this.shippingcharge=parseInt(data.value);
   
  }
  onclose(){
    this.dialogref.close();
     }

}
