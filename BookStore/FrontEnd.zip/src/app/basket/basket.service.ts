import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BasketService {

CouponDiscount=new Subject<number>();
ShippingCost=new Subject<number>();
TotalAmount=new Subject<number>();

url='http://localhost:51169/'
  constructor(public http:HttpClient) { }

  GetCatItemsByUserId(UserId:number):Observable<any>
  {
    return this.http.get<any>(this.url+'GetCartItem/'+UserId)
  }
  DeleteBook(BookId:number):Observable<any>{
    return this.http.delete<any>(this.url+'DeleteCartBook/'+BookId);
  }
  UpdateQuant(quant:any,id:any):Observable<any>{
    return this.http.put<any>(this.url+'UpdateCartItemQuant/'+id+'/'+quant,1);
  }
}
