import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BasketComponent } from './basket.component';
import { BasketRoutingModule } from './basket-routing.module';
import { SharedModule } from '../shared/shared.module';
import { RouterModule } from '@angular/router';
import { BasketCouponComponent } from './basket-coupon/basket-coupon.component';
import { BasketShippingOptionsComponent } from './basket-shipping-options/basket-shipping-options.component';







@NgModule({
  declarations: [
    BasketComponent,
    BasketCouponComponent,
    BasketShippingOptionsComponent,
  
  ],
  imports: [
    CommonModule,
    BasketRoutingModule,
    SharedModule,
    RouterModule,
    FormsModule,
    
    
  ],
  entryComponents:[BasketCouponComponent,BasketShippingOptionsComponent]
})
export class BasketModule { }
