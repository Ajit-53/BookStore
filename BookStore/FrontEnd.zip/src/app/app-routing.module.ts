import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ShopModule } from './shop/shop.module';
import { AdminModule } from './admin/admin.module';
import { AppGuard } from './app.guard';
import { AdminloginComponent } from './shared/adminlogin/adminlogin.component';
import { HomeLoginComponent } from './home/home-login/home-login.component';
import { HomeRegisterComponent } from './home/home-register/home-register.component';
import { HomeCartComponent } from './home/home-cart/home-cart.component';
import { HomeCheckoutComponent } from './home/home-checkout/home-checkout.component';
import { BasketModule } from './basket/basket.module';
import { UserGuard } from './user.guard';
import { CheckoutModule } from './checkout/checkout.module';
import { WhislistComponent } from './core/whislist/whislist.component';

const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'userlogin',component:HomeLoginComponent},
  {path:'basket',loadChildren:()=>import('./basket/basket.module').then(mod=>BasketModule),canActivate:[UserGuard]},
  {path:'whislist',component:WhislistComponent,canActivate:[UserGuard]},
  {path:'shop',loadChildren:()=>import('./shop/shop.module').then(mod=>ShopModule)},
  {path:'checkout',loadChildren:()=>import('./checkout/checkout.module').then(mod=>CheckoutModule)},
  {path:'admin',loadChildren:()=>import('./admin/admin.module').then(mod=>AdminModule),canActivate:[AppGuard]},
  
 
  {path:'userregister',component:HomeRegisterComponent},
 
  {path:'**',redirectTo:'',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
