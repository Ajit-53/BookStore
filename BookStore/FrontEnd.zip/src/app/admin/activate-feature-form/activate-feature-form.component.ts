import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-activate-feature-form',
  templateUrl: './activate-feature-form.component.html',
  styleUrls: ['./activate-feature-form.component.scss']
})
export class ActivateFeatureFormComponent implements OnInit {

 
  constructor(public adminservice:AdminService,public dialogref:MatDialogRef<ActivateFeatureFormComponent>) { }
 
 data={
   bookid:''
 }
 

 
  ngOnInit(): void {
   
  }
 

 Onsubmit(){
  this.adminservice.MakeFeatured(this.data.bookid).subscribe();
  this.onclose();

 } 

 onclose(){
this.dialogref.close();
 }


}
