import { Component, OnInit } from '@angular/core';
import { ShopService } from 'src/app/shop/shop.service';
import { AdminService } from '../admin.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-subcategory-form',
  templateUrl: './subcategory-form.component.html',
  styleUrls: ['./subcategory-form.component.scss']
})
export class SubcategoryFormComponent implements OnInit {

  imageUrl = '../../../assets/logo1.png';
  fileToUpload:any;
  public data2=
 {
   CatId:null,
   SubId:null,
   SubName:null,
   SubDesc:null,
   Price:null,
   Photo:'abc',
   ISBN:12860
 }
 posts1:any
 posts3:any
  constructor(public shopservice:ShopService,public adminservice:AdminService,public dialogref:MatDialogRef<SubcategoryFormComponent>) { }

  ngOnInit(): void {
    this.GetBookTitle();
  }


  onchange1(Data:any)
  {
    this.adminservice.GetCategorybyCatId(Data.value).subscribe((response)=>{
      this.posts3=response;
      console.log(this.posts3);
    })
  this.data2.CatId=Data.value;
  console.log(Data.value);
  }
  onchange2(Data:any)
  {
   this.data2.SubId=Data.value;
  console.log(Data.value);
  console.log(this.data2);
  }

  GetBookTitle()
  {
    this.shopservice.GetwithTitle().subscribe((response)=>{
      this.posts1=response;
      console.log(this.posts1);
    })
  }
  Onsubmit()
  {
    this.adminservice.AddBookSubCategory(this.data2).subscribe();
    this.onclose();
  }
  onclose()
  {
    this.dialogref.close();
  }

  onSelectFile(File:any)
  {
    this.fileToUpload =File.target.files[0]; 
    var reader = new FileReader();  
        reader.onload = (event: any) => {  
            this.imageUrl = event.target.result;  
            // console.log(1);
            //  console.log(event.target.result);
        }  
        reader.readAsDataURL(this.fileToUpload); 
    //     console.log(2);
    //  console.log(File.target.files[0]);
    //  console.log(3);
    //  console.log(this.logoinput)
    //  console.log(4);
    //  console.log(this.logoinput.nativeElement.files[0]);
  }
    


}
