import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  Url='http://localhost:51169/';
  constructor(public http:HttpClient) { }

  AddBook(data:any):Observable<any>{
    return this.http.post<any>(this.Url+'AddBookTitle',data);
    }
    AddBookCategory(data:any):Observable<any>{
      return this.http.post<any>(this.Url+'AddBookCategory',data);
    }
    AddBookSubCategory(data:any):Observable<any>{
        return this.http.post<any>(this.Url+'AddBookSubCategory',data);
    }
  GetCategorybyCatId(CatId:any):Observable<any>{
    return this.http.get<any>(this.Url+'GetBookCat/'+CatId);
  }
  AddCoupon(data:any):Observable<any>{
    return this.http.post<any>(this.Url+'AddCoupon',data);
    }
    ActivateCoupon(data:string):Observable<any>{
      return this.http.put<any>(this.Url+'ActivateCoupon/'+data,data);
      }
      DeactivateCoupon(data:string):Observable<any>{
        return this.http.put<any>(this.Url+'DeactivateCoupon/'+data,data);
        }
        GetCouponById(CouponId:any):Observable<any>{
          return this.http.get<any>(this.Url+'GetCoupons/'+CouponId);
        }       
        GetCoupon():Observable<any>{
          return this.http.get<any>(this.Url+'GetCoupons/');
        }  

         
  GetFeaturedBook():Observable<any>{
    return this.http.get<any>(this.Url+'GetFeaturedBook')
  } 
  GetActivatedCoupon():Observable<any>{
    return this.http.get<any>(this.Url+'GetActivatedCoupons');
  }  

  GetBlockedUser():Observable<any>{
    return this.http.get<any>(this.Url+'GetBlockedUser')
  } 

  GetZeroStatusBook():Observable<any>{
    return this.http.get<any>(this.Url+'GetZeroStatusBook')
  } 
  MakeNonFeatured(Bookid:any):Observable<any>{
    return this.http.put<any>(this.Url+'MakeNonFeature/'+Bookid,Bookid);
  }  
  MakeFeatured(Bookid:any):Observable<any>{
    return this.http.put<any>(this.Url+'MakeFeature/'+Bookid,Bookid);
  }   
  
  MakeVisible(Bookid:any):Observable<any>{
    return this.http.put<any>(this.Url+'MakeVisible/'+Bookid,Bookid);
  }

  MakeHidden(Bookid:any):Observable<any>{
    return this.http.put<any>(this.Url+'MakeHidden/'+Bookid,Bookid);
  }

  ActivateUser(Userid:any):Observable<any>{
    return this.http.put<any>(this.Url+'ActivateUser/'+Userid,Userid);
  }
  DeactivateUser(Userid:any):Observable<any>{
    return this.http.put<any>(this.Url+'BlockUser/'+Userid,Userid);
  }

  DeleteBookbyBookId(Bookid:any):Observable<any>{
    return this.http.delete<any>(this.Url+'DeleteBook/'+Bookid,Bookid);
  }
     
        
}
