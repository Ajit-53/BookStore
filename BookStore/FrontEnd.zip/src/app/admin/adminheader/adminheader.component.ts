import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-adminheader',
  templateUrl: './adminheader.component.html',
  styleUrls: ['./adminheader.component.scss']
})
export class AdminheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  user=localStorage.getItem('admin');
  

}
