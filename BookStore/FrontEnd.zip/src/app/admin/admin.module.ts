import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminComponent } from './admin.component';
import { HeaderComponent } from './header/header.component';
import { RouterModule } from '@angular/router';
import { HeaderCardsComponent } from './header-cards/header-cards.component';
import { AddbookComponent } from './addbook/addbook.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { AdminheaderComponent } from './adminheader/adminheader.component';
import { ApplycouponsComponent } from './applycoupons/applycoupons.component';
import { ChangeuserstatusComponent } from './changeuserstatus/changeuserstatus.component';
import { FeaturebooksComponent } from './featurebooks/featurebooks.component';
import { UpdatebookdetailsComponent } from './updatebookdetails/updatebookdetails.component';
import { ChangebookstatusComponent } from './changebookstatus/changebookstatus.component';
import { DeletebookComponent } from './deletebook/deletebook.component';
import { AddcouponsComponent } from './addcoupons/addcoupons.component';
import { FormsModule } from '@angular/forms';
import { CouponFormComponent } from './coupon-form/coupon-form.component';

import {MatDialogModule} from '@angular/material/dialog';
import { CategoryFormComponent } from './category-form/category-form.component';
import { SubcategoryFormComponent } from './subcategory-form/subcategory-form.component';
import { AddCouponFormComponent } from './add-coupon-form/add-coupon-form.component';
import { ActivateCouponFormComponent } from './activate-coupon-form/activate-coupon-form.component';
import { DeactivateCouponFormComponent } from './deactivate-coupon-form/deactivate-coupon-form.component';
import { DeactivateUserFormComponent } from './deactivate-user-form/deactivate-user-form.component';
import { ActivateUserFormComponent } from './activate-user-form/activate-user-form.component';
import { ActivateFeatureFormComponent } from './activate-feature-form/activate-feature-form.component';
import { DeactivateFeatureFormComponent } from './deactivate-feature-form/deactivate-feature-form.component';
import { DeactivateStatusBookFormComponent } from './deactivate-status-book-form/deactivate-status-book-form.component';
import { ActivateStatusBookFormComponent } from './activate-status-book-form/activate-status-book-form.component';
import { CoreModule } from '../core/core.module';
import { AdminRoutingModule } from './admin-routing.module';







@NgModule({
  declarations: [
    AdminComponent,
    HeaderComponent,
    HeaderCardsComponent,
    AddbookComponent,
    SidebarComponent,
    AdminheaderComponent,
    ApplycouponsComponent,
    ChangeuserstatusComponent,
    FeaturebooksComponent,
    UpdatebookdetailsComponent,
    ChangebookstatusComponent,
    DeletebookComponent,
    AddcouponsComponent,
    CouponFormComponent,
    CategoryFormComponent,
    SubcategoryFormComponent,
    AddCouponFormComponent,
    ActivateCouponFormComponent,
    DeactivateCouponFormComponent,
    DeactivateUserFormComponent,
    ActivateUserFormComponent,
    ActivateFeatureFormComponent,
    DeactivateFeatureFormComponent,
    DeactivateStatusBookFormComponent,
    ActivateStatusBookFormComponent,
    

    

    

    
    
  ],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    MatDialogModule,
    AdminRoutingModule,
    CoreModule
    
  ],
  exports:[AdminComponent],
  entryComponents:[
    CouponFormComponent,CategoryFormComponent,SubcategoryFormComponent,
    ActivateCouponFormComponent,AddCouponFormComponent,DeactivateCouponFormComponent,
    ActivateFeatureFormComponent,DeactivateFeatureFormComponent,ActivateStatusBookFormComponent,
    DeactivateStatusBookFormComponent,DeletebookComponent]
})
export class AdminModule { }
