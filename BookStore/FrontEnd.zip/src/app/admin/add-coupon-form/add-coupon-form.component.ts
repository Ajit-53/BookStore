import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-add-coupon-form',
  templateUrl: './add-coupon-form.component.html',
  styleUrls: ['./add-coupon-form.component.scss']
})
export class AddCouponFormComponent implements OnInit {

data={
  CouponCode:'',
  CouponDiscount:''
}
items:number[]=[10,20,30,40,50,60,70];

  constructor(public adminservice:AdminService,public dialogref:MatDialogRef<AddCouponFormComponent>) { }

  ngOnInit(): void {
  }

 onchange(Data:any){
   this.data.CouponDiscount=Data.Value;
   console.log(this.data.CouponDiscount);
 } 

 Onsubmit()
 {
   this.adminservice.AddCoupon(this.data).subscribe();
   this.onclose();
 }
 onclose(){
this.dialogref.close();
 }

}
