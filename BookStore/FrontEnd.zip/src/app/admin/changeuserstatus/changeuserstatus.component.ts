import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivateUserFormComponent } from '../activate-user-form/activate-user-form.component';
import { DeactivateUserFormComponent } from '../deactivate-user-form/deactivate-user-form.component';

@Component({
  selector: 'app-changeuserstatus',
  templateUrl: './changeuserstatus.component.html',
  styleUrls: ['./changeuserstatus.component.scss']
})
export class ChangeuserstatusComponent implements OnInit {

  constructor(public dialog:MatDialog) { }

  ngOnInit(): void {
  }

  onclick1()
  {
    this.dialog.open(DeactivateUserFormComponent);
  } 
  onclick2()
  {
    this.dialog.open(ActivateUserFormComponent);
  } 
 


}
