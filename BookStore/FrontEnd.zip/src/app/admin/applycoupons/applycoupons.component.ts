import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddCouponFormComponent } from '../add-coupon-form/add-coupon-form.component';
import { ActivateCouponFormComponent } from '../activate-coupon-form/activate-coupon-form.component';
import { DeactivateCouponFormComponent } from '../deactivate-coupon-form/deactivate-coupon-form.component';

@Component({
  selector: 'app-applycoupons',
  templateUrl: './applycoupons.component.html',
  styleUrls: ['./applycoupons.component.scss']
})
export class ApplycouponsComponent implements OnInit {

  constructor(public dialog:MatDialog) { }

  ngOnInit(): void {
  }


  onclick1()
 {
   this.dialog.open(AddCouponFormComponent);
 } 
 onclick2()
 {
   this.dialog.open(ActivateCouponFormComponent);
 } 
 onclick3()
 {
   this.dialog.open(DeactivateCouponFormComponent);
 } 

}
