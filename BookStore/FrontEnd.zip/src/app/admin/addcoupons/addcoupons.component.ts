import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addcoupons',
  templateUrl: './addcoupons.component.html',
  styleUrls: ['./addcoupons.component.scss']
})
export class AddcouponsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
