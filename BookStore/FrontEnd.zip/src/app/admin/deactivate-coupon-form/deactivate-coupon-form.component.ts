import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-deactivate-coupon-form',
  templateUrl: './deactivate-coupon-form.component.html',
  styleUrls: ['./deactivate-coupon-form.component.scss']
})
export class DeactivateCouponFormComponent implements OnInit {
  posts1:any
  couponcode:any
  constructor(public adminservice:AdminService,public dialogref:MatDialogRef<DeactivateCouponFormComponent>) { }

  
  
  ngOnInit(): void {
    this.GetCoupon();
  }
  GetCoupon()
  {
    this.adminservice.GetCoupon().subscribe((res)=>{
      this.posts1=res;
    })
  }
  onchange(Data:any)
  {
    this.couponcode=Data.value;
    console.log(this.couponcode);
  }

 Onsubmit(){
  this.adminservice.DeactivateCoupon(this.couponcode).subscribe();
  this.onclose();

 } 

 onclose(){
this.dialogref.close();
 }


}
