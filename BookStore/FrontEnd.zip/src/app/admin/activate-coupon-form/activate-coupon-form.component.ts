import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AdminService } from '../admin.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-activate-coupon-form',
  templateUrl: './activate-coupon-form.component.html',
  styleUrls: ['./activate-coupon-form.component.scss']
})
export class ActivateCouponFormComponent implements OnInit {


  constructor(public adminservice:AdminService,public dialogref:MatDialogRef<ActivateCouponFormComponent>) { }
 posts1:any
 couponcode:any
 

 
  ngOnInit(): void {
    this.GetCoupon();
  }
  GetCoupon()
  {
    this.adminservice.GetCoupon().subscribe((res)=>{
      
      this.posts1=res;
    })
  }
  onchange(Data:any)
  {
    this.couponcode=Data.value;
  
  }

 Onsubmit(){
  this.adminservice.ActivateCoupon(this.couponcode).subscribe();
  this.onclose();

 } 

 onclose(){
this.dialogref.close();
 }

}
function foreach() {
  throw new Error('Function not implemented.');
}

