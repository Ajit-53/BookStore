import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-deactivate-feature-form',
  templateUrl: './deactivate-feature-form.component.html',
  styleUrls: ['./deactivate-feature-form.component.scss']
})
export class DeactivateFeatureFormComponent implements OnInit {

  constructor(public adminservice:AdminService,public dialogref:MatDialogRef<DeactivateFeatureFormComponent>) { }
 posts1:any
 Bookid:any
 

 
  ngOnInit(): void {
    this.GetFeature();
  }
  GetFeature()
  {
    this.adminservice.GetFeaturedBook().subscribe((res)=>{
      
      this.posts1=res;
    })
  }
  onchange(Data:any)
  {
    this.Bookid=Data.value;
  
  }

 Onsubmit(){
  this.adminservice.MakeNonFeatured(this.Bookid).subscribe();
  this.onclose();

 } 

 onclose(){
this.dialogref.close();
 }

}
