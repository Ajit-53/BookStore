import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-deactivate-status-book-form',
  templateUrl: './deactivate-status-book-form.component.html',
  styleUrls: ['./deactivate-status-book-form.component.scss']
})
export class DeactivateStatusBookFormComponent implements OnInit {

  
  constructor(public adminservice:AdminService,public dialogref:MatDialogRef<DeactivateStatusBookFormComponent>) { }
 
 data={
   bookid:''
 }
 

 
  ngOnInit(): void {
   
  }
 

 Onsubmit(){
  this.adminservice.MakeHidden(this.data.bookid).subscribe();
  this.onclose();

 } 

 onclose(){
this.dialogref.close();
 }


}
