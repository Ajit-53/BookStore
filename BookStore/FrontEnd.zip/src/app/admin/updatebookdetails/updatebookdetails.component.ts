import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatebookdetails',
  templateUrl: './updatebookdetails.component.html',
  styleUrls: ['./updatebookdetails.component.scss']
})
export class UpdatebookdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
