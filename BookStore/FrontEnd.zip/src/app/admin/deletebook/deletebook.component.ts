import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-deletebook',
  templateUrl: './deletebook.component.html',
  styleUrls: ['./deletebook.component.scss']
})
export class DeletebookComponent implements OnInit {

  bookid:any
    constructor(public dialogref:MatDialogRef<DeletebookComponent>,public service:AdminService) { }
  
    ngOnInit(): void {
    }
  Onsubmit()
  {
    this.service.DeleteBookbyBookId(this.bookid).subscribe();
    console.log(this.bookid);
    this.onclose();
  }
  onclose(){
    this.dialogref.close();
  }

}
