import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin.component';
import { AddbookComponent } from './addbook/addbook.component';
import { DeletebookComponent } from './deletebook/deletebook.component';
import { ApplycouponsComponent } from './applycoupons/applycoupons.component';
import { ChangeuserstatusComponent } from './changeuserstatus/changeuserstatus.component';
import { FeaturebooksComponent } from './featurebooks/featurebooks.component';
import { UpdatebookdetailsComponent } from './updatebookdetails/updatebookdetails.component';
import { ChangebookstatusComponent } from './changebookstatus/changebookstatus.component';



const routes:Routes=
[
  {path:'',children:[{path:'',component:AdminComponent},
    {path:'addbook',component:AddbookComponent,},
    {path:'deletebook',component:DeletebookComponent},
    {path:'coupons',component:ApplycouponsComponent},
    {path:'changeuserstatus',component:ChangeuserstatusComponent},
    {path:'featuredbooks',component:FeaturebooksComponent},
    {path:'updatebookdetails',component:UpdatebookdetailsComponent},
    {path:'bookstatus',component:ChangebookstatusComponent},
    
  ]},
   
  
  
]

@NgModule({
  declarations: [],
  imports: [
    RouterModule.forChild(routes)
  ]
})
export class AdminRoutingModule { }
