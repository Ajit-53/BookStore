import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-activate-status-book-form',
  templateUrl: './activate-status-book-form.component.html',
  styleUrls: ['./activate-status-book-form.component.scss']
})
export class ActivateStatusBookFormComponent implements OnInit {

 
  constructor(public adminservice:AdminService,public dialogref:MatDialogRef<ActivateStatusBookFormComponent>) { }
 posts1:any
 Bookid:any
 

 
  ngOnInit(): void {
    this.GetFeature();
  }
  GetFeature()
  {
    this.adminservice.GetZeroStatusBook().subscribe((res)=>{
      
      this.posts1=res;
    })
  }
  onchange(Data:any)
  {
    this.Bookid=Data.value;
    console.log(Data.value);
  
  }

 Onsubmit(){
  this.adminservice.MakeVisible(this.Bookid).subscribe();
  this.onclose();

 } 

 onclose(){
this.dialogref.close();
 }

}
