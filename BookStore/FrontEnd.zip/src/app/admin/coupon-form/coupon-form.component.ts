import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-coupon-form',
  templateUrl: './coupon-form.component.html',
  styleUrls: ['./coupon-form.component.scss']
})
export class CouponFormComponent implements OnInit {
data={
  title:''
}
  constructor(public dialogref:MatDialogRef<CouponFormComponent>,public service:AdminService) { }

  ngOnInit(): void {
  }
Onsubmit()
{
  this.service.AddBook(this.data).subscribe();
  console.log(this.data.title);
  this.onclose();
}
onclose(){
  this.dialogref.close();
}
}
