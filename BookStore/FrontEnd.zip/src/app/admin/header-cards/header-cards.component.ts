import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-cards',
  templateUrl: './header-cards.component.html',
  styleUrls: ['./header-cards.component.scss']
})
export class HeaderCardsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
