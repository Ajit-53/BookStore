import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { CouponFormComponent } from '../coupon-form/coupon-form.component';
import { CategoryFormComponent } from '../category-form/category-form.component';
import { SubcategoryFormComponent } from '../subcategory-form/subcategory-form.component';

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.scss']
})
export class AddbookComponent implements OnInit {

  constructor(private dialog:MatDialog) { }

  ngOnInit(): void {
  }

 onclick1()
 {
   this.dialog.open(CouponFormComponent);
 } 
 onclick2()
 {
   this.dialog.open(CategoryFormComponent);
 } 
 onclick3()
 {
   this.dialog.open(SubcategoryFormComponent);
 } 

}
