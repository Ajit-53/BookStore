import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-deactivate-user-form',
  templateUrl: './deactivate-user-form.component.html',
  styleUrls: ['./deactivate-user-form.component.scss']
})
export class DeactivateUserFormComponent implements OnInit {
userid:any
    constructor(public dialogref:MatDialogRef<DeactivateUserFormComponent>,public service:AdminService) { }
  
    ngOnInit(): void {
    }
  Onsubmit()
  {
    this.service.DeactivateUser(this.userid).subscribe();
    console.log(this.userid);
    this.onclose();
  }
  onclose(){
    this.dialogref.close();
  }

}
