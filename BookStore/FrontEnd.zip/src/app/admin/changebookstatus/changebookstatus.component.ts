import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivateStatusBookFormComponent } from '../activate-status-book-form/activate-status-book-form.component';
import { DeactivateStatusBookFormComponent } from '../deactivate-status-book-form/deactivate-status-book-form.component';

@Component({
  selector: 'app-changebookstatus',
  templateUrl: './changebookstatus.component.html',
  styleUrls: ['./changebookstatus.component.scss']
})
export class ChangebookstatusComponent implements OnInit {
  constructor(public dialog:MatDialog) { }

  ngOnInit(): void {
  }

  onclick1()
  {
    this.dialog.open(ActivateStatusBookFormComponent);
  } 
  onclick2()
  {
    this.dialog.open(DeactivateStatusBookFormComponent);
  } 

}
