import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-activate-user-form',
  templateUrl: './activate-user-form.component.html',
  styleUrls: ['./activate-user-form.component.scss']
})
export class ActivateUserFormComponent implements OnInit {

  constructor(public adminservice:AdminService,public dialogref:MatDialogRef<ActivateUserFormComponent>) { }
 posts1:any
 userid:any
 

 
  ngOnInit(): void {
    this.GetblockUser();
  }
  GetblockUser()
  {
    this.adminservice.GetBlockedUser().subscribe((res)=>{
      this.posts1=res;
    })
  }
  onchange(Data:any)
  {
    this.userid=Data.value;
  
  }

 Onsubmit(){
  this.adminservice.ActivateUser(this.userid).subscribe();
  this.onclose();

 } 

 onclose(){
this.dialogref.close();
 }
}
