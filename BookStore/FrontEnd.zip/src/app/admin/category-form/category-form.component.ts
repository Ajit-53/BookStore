import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { ShopService } from 'src/app/shop/shop.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-category-form',
  templateUrl: './category-form.component.html',
  styleUrls: ['./category-form.component.scss']
})
export class CategoryFormComponent implements OnInit {

  public data =
  {
    CatId:null,
    CatName: null,
  } 
  posts1:any
 posts2:any
 posts3:any
  constructor(public adminservice:AdminService,public shopservice:ShopService,public dialogref:MatDialogRef<CategoryFormComponent>) { }

  ngOnInit(): void {
   
    
    this.GetBookTitle();
  }
  onchange(Data:any)
  {
  this.data.CatId=Data.value;
  console.log(Data.value);
  }

  GetBookTitle()
  {
    this.shopservice.GetwithTitle().subscribe((response)=>{
      this.posts1=response;
      console.log(this.posts1);
    })
  }
  Onsubmit()
  {
    this.adminservice.AddBookCategory(this.data).subscribe();
    this.onclose();
  }
  onclose()
  {
    this.dialogref.close();
  }

}
