import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivateFeatureFormComponent } from '../activate-feature-form/activate-feature-form.component';
import { DeactivateFeatureFormComponent } from '../deactivate-feature-form/deactivate-feature-form.component';

@Component({
  selector: 'app-featurebooks',
  templateUrl: './featurebooks.component.html',
  styleUrls: ['./featurebooks.component.scss']
})
export class FeaturebooksComponent implements OnInit {

  constructor(public dialog:MatDialog) { }

  ngOnInit(): void {
  }

  onclick1()
  {
    this.dialog.open(ActivateFeatureFormComponent);
  } 
  onclick2()
  {
    this.dialog.open(DeactivateFeatureFormComponent);
  } 
}
