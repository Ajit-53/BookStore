import { Component, OnInit } from '@angular/core';
import { AppService } from 'src/app/app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  

  constructor(public appservice:AppService,public r:Router) { }

  ngOnInit(): void {
  }
  onclick()
    {
      this.appservice.Adminlogout();
      this.r.navigateByUrl("/shop")
    }
  
router=localStorage.getItem('admin');
}
